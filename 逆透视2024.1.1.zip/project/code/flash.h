#ifndef __FLASH_h
#define __FLASH_h

void save_data(int sector_num,int page_num,int save_num);
void read_data(int sector_num,int page_num,int save_num);

#endif


