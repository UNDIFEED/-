#ifndef __CONTROL_H
#define __CONTROL_H
#include "zf_common_headfile.h"

extern uint8 MotorBegin_Flag; //启动标志位

void Mode_Switch(void);

#endif
