#ifndef _upcomputer_h_
#define _upcomputer_h_

void Upcomputer_Send(float data1, float data2, float data3, float data4);

#endif